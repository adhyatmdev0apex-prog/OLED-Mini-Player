# Media slot: `v0001`

Place real, ESP32-compatible files here:

- `video.bin`
- `audio.bin`

The catalogue deliberately lists this slot even while files are absent, so the browser and ESP32 can exercise missing-media handling. Do not add generated or dummy binary files.
