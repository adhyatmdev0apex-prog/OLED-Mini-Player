# ESP32 Media Library

A dependency-free Node.js content server and browser test UI. It holds the permanent media and exposes a paginated catalogue with direct download URLs. It does not implement OTA or ESP32 filesystem storage.

## Run locally

Requires Node.js 18+.

```sh
cd WEB
npm start
```

Open `http://localhost:3000`. To make it available to a device on your LAN, find your computer's LAN IP and use `http://YOUR_LAN_IP:3000` on the ESP32-CAM. Make sure the firewall permits the selected port.

Configuration is in `config.json`. Environment overrides: `PORT`, `HOST`, `CORS_ENABLED=true|false`, and `CORS_ORIGIN`.

## API

The firmware-ready request/response specification and download sequence are in [API.md](API.md).

```sh
curl "http://localhost:3000/api/videos?page=0&limit=10"
curl -i "http://localhost:3000/media/v0001/video.bin"
```

`GET /api/videos?page=0&limit=10` returns `page`, `limit`, `total`, and catalogue `items`. `page` is zero-based. The configured maximum page size is 50. Invalid parameters return HTTP 400 and JSON error details. Unknown IDs and absent files return HTTP 404 JSON errors.

The ESP32-CAM should request the catalogue URL, choose an item, prepend its server base URL to the returned relative `video_url` / `audio_url`, then fetch those URLs directly. For example, `/media/v0001/video.bin` becomes `http://192.168.1.10:3000/media/v0001/video.bin`.

## Add a real video

1. Create `media/v0002/`.
2. Put real `video.bin` and `audio.bin` in it. No dummy binaries are included in this project.
3. Add an entry to `data/catalogue.json`:

```json
{
  "id": "v0002",
  "name": "My animation",
  "video_file": "video.bin",
  "audio_file": "audio.bin",
  "metadata": { "description": "Optional information" }
}
```

IDs must be unique and use letters, numbers, `_`, or `-`. Restart the server after editing the catalogue (the API reads it per request, but restart is the simplest operational workflow).

## Tests

```sh
npm test
```

The test suite verifies catalogue JSON, pagination, invalid-query handling, missing-ID handling, and missing-media handling. After placing actual files, test downloads with the browser or `curl -O` using the exact URL returned by the API.
