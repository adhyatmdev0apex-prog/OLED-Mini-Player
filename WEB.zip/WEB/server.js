'use strict';

const http = require('node:http');
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const MEDIA_DIR = path.join(ROOT, 'media');
const CATALOGUE_FILE = path.join(ROOT, 'data', 'catalogue.json');
const CONFIG_FILE = path.join(ROOT, 'config.json');

function loadJson(file) {
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function loadConfig() {
  const config = loadJson(CONFIG_FILE);
  return {
    host: process.env.HOST || config.host || '0.0.0.0',
    port: Number(process.env.PORT || config.port || 3000),
    cors: {
      enabled: process.env.CORS_ENABLED ? process.env.CORS_ENABLED === 'true' : config.cors?.enabled !== false,
      origin: process.env.CORS_ORIGIN || config.cors?.origin || '*'
    },
    pagination: config.pagination || { defaultLimit: 10, maxLimit: 50 }
  };
}

const config = loadConfig();

function sendJson(res, status, value) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(value, null, 2));
}

function sendError(res, status, code, message) {
  sendJson(res, status, { error: { code, message } });
}

function applyCors(res) {
  if (config.cors.enabled) {
    res.setHeader('Access-Control-Allow-Origin', config.cors.origin);
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  }
}

function catalogue() {
  const source = loadJson(CATALOGUE_FILE);
  if (!Array.isArray(source.videos)) throw new Error('catalogue.json must contain a videos array');
  return source.videos;
}

function publicItem(item) {
  const base = `/media/${encodeURIComponent(item.id)}`;
  return {
    id: item.id,
    name: item.name,
    video_url: `${base}/${encodeURIComponent(item.video_file || 'video.bin')}`,
    audio_url: `${base}/${encodeURIComponent(item.audio_file || 'audio.bin')}`,
    ...(item.metadata ? { metadata: item.metadata } : {})
  };
}

function positiveInteger(value, name, fallback, max) {
  if (value === null) return fallback;
  if (!/^\d+$/.test(value)) throw new Error(`${name} must be a non-negative integer`);
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || parsed > max) throw new Error(`${name} must be between 0 and ${max}`);
  return parsed;
}

function safeMediaPath(id, filename) {
  if (!/^[A-Za-z0-9_-]+$/.test(id) || !/^[A-Za-z0-9._-]+$/.test(filename)) return null;
  const filePath = path.resolve(MEDIA_DIR, id, filename);
  return filePath.startsWith(`${path.resolve(MEDIA_DIR)}${path.sep}`) ? filePath : null;
}

async function serveFile(res, filePath, contentType) {
  try {
    const info = await fsp.stat(filePath);
    if (!info.isFile()) return sendError(res, 404, 'MEDIA_NOT_FOUND', 'Media file was not found.');
    res.writeHead(200, {
      'Content-Type': contentType,
      'Content-Length': info.size,
      'Content-Disposition': `attachment; filename="${path.basename(filePath)}"`,
      'Cache-Control': 'public, max-age=3600'
    });
    fs.createReadStream(filePath).pipe(res);
  } catch (error) {
    if (error.code === 'ENOENT') return sendError(res, 404, 'MEDIA_NOT_FOUND', 'Media file was not found.');
    console.error('[media] failed:', error);
    sendError(res, 500, 'MEDIA_READ_ERROR', 'Could not read media file.');
  }
}

async function requestHandler(req, res) {
  const started = Date.now();
  applyCors(res);
  res.on('finish', () => console.log(`[${new Date().toISOString()}] ${req.method} ${req.url} ${res.statusCode} ${Date.now() - started}ms`));
  if (req.method === 'OPTIONS') return res.writeHead(204).end();
  if (req.method !== 'GET') return sendError(res, 405, 'METHOD_NOT_ALLOWED', 'Only GET and OPTIONS are supported.');

  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (url.pathname === '/api/videos') {
    try {
      const page = positiveInteger(url.searchParams.get('page'), 'page', 0, Number.MAX_SAFE_INTEGER);
      const limit = positiveInteger(url.searchParams.get('limit'), 'limit', config.pagination.defaultLimit, config.pagination.maxLimit);
      if (limit < 1) return sendError(res, 400, 'INVALID_QUERY', 'limit must be at least 1.');
      const all = catalogue().map(publicItem);
      return sendJson(res, 200, { page, limit, total: all.length, items: all.slice(page * limit, page * limit + limit) });
    } catch (error) {
      return sendError(res, 400, 'INVALID_QUERY', error.message);
    }
  }

  const mediaMatch = url.pathname.match(/^\/media\/([^/]+)\/([^/]+)$/);
  if (mediaMatch) {
    let id;
    let filename;
    try {
      id = decodeURIComponent(mediaMatch[1]);
      filename = decodeURIComponent(mediaMatch[2]);
    } catch {
      return sendError(res, 400, 'INVALID_MEDIA_PATH', 'Invalid URL encoding in media path.');
    }
    const known = catalogue().find((item) => item.id === id);
    if (!known) return sendError(res, 404, 'VIDEO_NOT_FOUND', `Video '${id}' does not exist.`);
    if (filename !== (known.video_file || 'video.bin') && filename !== (known.audio_file || 'audio.bin')) {
      return sendError(res, 404, 'MEDIA_NOT_FOUND', 'Requested file is not listed for this video.');
    }
    const filePath = safeMediaPath(id, filename);
    if (!filePath) return sendError(res, 400, 'INVALID_MEDIA_PATH', 'Invalid media path.');
    return serveFile(res, filePath, 'application/octet-stream');
  }

  const staticPath = url.pathname === '/' ? 'index.html' : url.pathname.slice(1);
  const filePath = path.resolve(PUBLIC_DIR, staticPath);
  if (!filePath.startsWith(`${path.resolve(PUBLIC_DIR)}${path.sep}`)) return sendError(res, 403, 'FORBIDDEN', 'Invalid path.');
  const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8' };
  return serveFile(res, filePath, types[path.extname(filePath)] || 'application/octet-stream');
}

function createServer() { return http.createServer(requestHandler); }

if (require.main === module) {
  createServer().listen(config.port, config.host, () => console.log(`ESP32 media library: http://localhost:${config.port}`));
}

module.exports = { createServer };
